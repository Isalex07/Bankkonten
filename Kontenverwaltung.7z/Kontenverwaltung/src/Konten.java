import java.util.concurrent.ThreadLocalRandom;

public abstract class Konten {

	public int Kontonummer;
	public double Gebuehrensatz;
	public double Kontostand;
	public Konten() {
		Kontonummer = 000000000;
		Gebuehrensatz = 3;
	}
	public double getKontostand(){
		return Kontostand;
	}
	public void setKontostand(double Kontostand){
		this.Kontostand = Kontostand;
	}
	
	public int getKontonnumer(){
		return Kontonummer;
	}
	public void setKontonummer(int Kontonummer){
		this.Kontonummer = Kontonummer;
	}
	public double getGebuehrensatz(){
		return Gebuehrensatz;
	}
	public void setGebuehrensatz(double Gebuehrensatz){
		this.Gebuehrensatz = Gebuehrensatz;
	}
	
	public void Kontonummerzeugen() {
		Kontonummer = ThreadLocalRandom.current().nextInt(000000000,999999999);		
		setKontonummer(Kontonummer);
	}
	public abstract void Kontostand();
	
	public void einzahlen(double Einzahlung){
		setKontostand(getKontostand()+Einzahlung);
		setGebuehrensatz(0);
	}
	
	public void auszahlen(double Auszahlung){
		setKontostand(getKontostand()-Auszahlung);
		setGebuehrensatz(0.20);
	}
	
}
