
public abstract class Girokonten extends Konten{
		int Girokontonummer;
				
		public int getGiroKontonummer(){
			Girokontonummer = getKontonnumer() + 2000000000;
			return Girokontonummer;
		}
		public void setGiroKontonummer(int Girokontonummer){
			this.Girokontonummer = Girokontonummer;
		}
		@Override
		public void Kontostand() {
			int k_num = getKontonnumer();
			if(k_num > 1000){
				setGebuehrensatz(0);
			}
		}
		public void GeldauszahlenGK(double Auszahlung){
			double neuerKontostand = getKontostand()-(Auszahlung);
			if(neuerKontostand>(-5000)){
				setKontostand(neuerKontostand);
			}			
		}
}
