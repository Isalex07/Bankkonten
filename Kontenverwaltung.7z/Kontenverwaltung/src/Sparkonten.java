
public abstract class Sparkonten extends Konten{
	
	int Sparkontonummer;
	
	public int getSparkontonummer(){		
		Sparkontonummer = getKontonnumer() + 1000000000;
		return Sparkontonummer;
	}
	public void setSparkontonummer(int Sparkontonummer){
		this.Sparkontonummer = Sparkontonummer;
	}
	@Override
	public void Kontostand() {
		int k_num = getKontonnumer();
		if(k_num > 1000){
			setGebuehrensatz(0);
		}
		
	}
	
	
}
